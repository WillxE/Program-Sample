#import <React/RCTViewManager.h>

@interface RCTVideoManager : RCTViewManager

@end
