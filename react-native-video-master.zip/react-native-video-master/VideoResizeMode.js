import keyMirror from 'keymirror';

export default keyMirror({
  contain: null,
  cover: null,
  stretch: null,
});
